﻿---
name: frontend-ui-design
description: 前端 UI/UX 设计。输出组件树、页面布局、状态管理、交互流程。不涉及具体编码
---

# 前端 UI 设计

## 核心原则

**先想清楚页面怎么长的，再写代码。**

UI 设计不是画画，是回答：这个页面有几种状态？用户进来先看到什么？

## 输出格式

```markdown
### 页面/组件：{name}
- 功能：{做什么}
- 布局：{页面区域的划分}
- 状态：{loading / empty / error / normal}
- 交互：{点击→跳转、输入→搜索等}
- 数据：{来自哪个 API / Store}
```

## The Gate Function

```
1. 确定页面/组件的功能
2. 画布局结构（区域划分）
3. 定义所有 UI 状态（loading, empty, error, normal）
4. 描述交互流程
5. 标注数据来源
```

## Rationalization Prevention

| 想说的话 | 真相 |
|---------|------|
| 「这个页面很标准，不用设计」 | 标准的页面也要确认每个状态。empty 状态长什么样？|
| 「先写代码再调样式」 | 没有布局规划 → 写完了发现结构不对 → 大改 |
